package com.geektrust.backend.commands;

import java.util.List;

import com.geektrust.backend.repositories.AppartmentRepository;
// import com.geektrust.backend.entities.WaterTanker;
import com.geektrust.backend.services.CalculateBill;

public class BillCommand implements ICommand{
    private AppartmentRepository appartmentRepository;
    private CalculateBill calculateBill;
    
    public BillCommand(AppartmentRepository appartmentRepository, CalculateBill calculateBill) {
        this.appartmentRepository = appartmentRepository;
        this.calculateBill = calculateBill;
    }

    @Override
    public void execute(List<String> tokens) {
        // TODO Auto-generated method stub
        Integer id = 0;
        System.out.print(calculateBill.totalWater(appartmentRepository.getAppartmentById(id))+" "+calculateBill.totalBill(appartmentRepository.getWaterDistributionById(id),appartmentRepository.getAppartmentById(id)));
        // System.out.println(calculateBill.totalWater()+" "+calculateBill.totalBill()+" "+calculateBill.getAppartment().extraWater()+" "+calculateBill.getWaterTanker().getRatePerLiter());
    }
    
}
