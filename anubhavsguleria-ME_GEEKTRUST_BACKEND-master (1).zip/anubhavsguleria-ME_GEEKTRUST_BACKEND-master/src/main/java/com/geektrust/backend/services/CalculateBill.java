package com.geektrust.backend.services;

import com.geektrust.backend.entities.Appartment;
import com.geektrust.backend.entities.WaterDistribution;


public class CalculateBill {
    
    public Integer totalWater(Appartment appartment){
        return appartment.waterAlloted()+appartment.extraWater();
    }

    private Integer getCorporationWaterAmount(WaterDistribution waterDistribution, Appartment appartment){
        Integer[] intRatios = waterDistribution.getIntRatio();
        double corporationWaterRatio = intRatios[0]/((double)(intRatios[0]+intRatios[1]));
        double corporationWaterAmount = waterDistribution.returnRates()[0]*(appartment.waterAlloted()*corporationWaterRatio);
        return (int)Math.ceil(corporationWaterAmount);
    }

    private Integer getBoreWellWaterAmount(WaterDistribution waterDistribution,Appartment appartment){
        Integer[] intRatios = waterDistribution.getIntRatio();
        double boreWellWaterRatio = intRatios[1]/((double)(intRatios[0]+intRatios[1]));
        double boreWellWaterAmount = waterDistribution.returnRates()[1]*(appartment.waterAlloted()*boreWellWaterRatio);
        return (int)Math.ceil(boreWellWaterAmount);
    }
    public Integer totalBill(WaterDistribution waterDistribution,Appartment appartment){
        Integer tankerWaterAmount = waterDistribution.calculateWaterTankerRate(appartment.extraWater());
        return getCorporationWaterAmount(waterDistribution,appartment)+getBoreWellWaterAmount(waterDistribution,appartment)+tankerWaterAmount;
    }
}
