package com.geektrust.backend.entities;

public class WaterDistribution {
    private Double corporationWaterRate;
    private Double borewellWaterRate;
    private String ratio;
    public WaterDistribution(Double corporationWaterRate, Double borewellWaterRate, String ratio) {
        this.corporationWaterRate = corporationWaterRate;
        this.borewellWaterRate = borewellWaterRate;
        this.ratio = ratio;
    }
    public WaterDistribution() {
        this.corporationWaterRate = 1.0;
        this.borewellWaterRate = 1.5;
        this.ratio = "";
    }

    
    public WaterDistribution(String ratio) {
        this.corporationWaterRate = 1.0;
        this.borewellWaterRate = 1.5;
        this.ratio = ratio;
    }
    
    public Integer[] getIntRatio(){
        String[] ratios = this.ratio.split(":");
        Integer[] intRatios = new Integer[2];
        intRatios[0] = Integer.valueOf(ratios[0]);
        intRatios[1] = Integer.valueOf(ratios[1]);
        return intRatios;
    }

    public Double[] returnRates(){
        Double[] rates = new Double[2];
        rates[0] = corporationWaterRate;
        rates[1] = borewellWaterRate;
        return rates;
    }

    public Integer calculateWaterTankerRate(Integer exteraWater) {
        Integer rate = 0;
        Integer slab1500 = 11500;
        Integer slab500 = 4000;
        Integer slab0 = 1000;
        if(exteraWater>=3000){
            rate = ((exteraWater-3000)*8)+slab1500;
        }else if(exteraWater>=1500) rate = ((exteraWater-1500)*5)+slab500;
        else if(exteraWater>=500) rate = ((exteraWater-500)*3)+slab0;
        else rate = exteraWater*2;
        return rate;
    }
}
