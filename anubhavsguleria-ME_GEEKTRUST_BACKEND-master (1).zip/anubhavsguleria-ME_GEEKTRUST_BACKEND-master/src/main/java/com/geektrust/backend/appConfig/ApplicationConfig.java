package com.geektrust.backend.appConfig;
import com.geektrust.backend.commands.AddGuestsCommand;
import com.geektrust.backend.commands.AllotWaterCommand;
import com.geektrust.backend.commands.BillCommand;
import com.geektrust.backend.commands.CommandInvoker;
import com.geektrust.backend.repositories.AppartmentRepository;
import com.geektrust.backend.repositories.AppartmentStrength;
import com.geektrust.backend.services.CalculateBill;

public class ApplicationConfig {
    
    private final AppartmentRepository appartmentRepository = new AppartmentRepository();
    private final AppartmentStrength appartmentStrength = new AppartmentStrength();
    private final CalculateBill calculateBill = new CalculateBill();
    private final AddGuestsCommand addGuestsCommand = new AddGuestsCommand(appartmentRepository);
    private final AllotWaterCommand allotWaterCommand = new AllotWaterCommand(appartmentRepository,appartmentStrength);
    private final BillCommand billCommand = new BillCommand(appartmentRepository,calculateBill);
    private final CommandInvoker commandInvoker = new CommandInvoker();
    public CommandInvoker getCommandInvoker(){
        commandInvoker.register("ALLOT_WATER", allotWaterCommand);
        commandInvoker.register("ADD_GUESTS", addGuestsCommand);
        commandInvoker.register("BILL", billCommand);
        return commandInvoker;
    }

}
