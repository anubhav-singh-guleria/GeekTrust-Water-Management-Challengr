package com.geektrust.backend.exceptions;

public class AppartmentTypeNotFoundException extends RuntimeException{

    public AppartmentTypeNotFoundException() {
        super();
    }

    public AppartmentTypeNotFoundException(String message) {
        super(message);
    }
    
}
