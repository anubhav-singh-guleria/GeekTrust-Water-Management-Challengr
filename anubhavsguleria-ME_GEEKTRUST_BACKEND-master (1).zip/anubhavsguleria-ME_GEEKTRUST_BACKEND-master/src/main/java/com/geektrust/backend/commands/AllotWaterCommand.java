package com.geektrust.backend.commands;
import java.util.List;


import com.geektrust.backend.entities.Appartment;
import com.geektrust.backend.entities.WaterDistribution;

import com.geektrust.backend.repositories.AppartmentRepository;
import com.geektrust.backend.repositories.AppartmentStrength;

public class AllotWaterCommand implements ICommand{

    private AppartmentRepository appartmentRepository;
    private AppartmentStrength appartmentStrength;
    public AllotWaterCommand(AppartmentRepository appartmentRepository, AppartmentStrength appartmentStrength) {
        this.appartmentRepository = appartmentRepository;
        this.appartmentStrength = appartmentStrength;
    }
    @Override
    public void execute(List<String> tokens) {
        appartmentStrength.add("2", 3);
        appartmentStrength.add("3", 5);
        appartmentRepository.addAppartment(new Appartment(tokens.get(1), appartmentStrength.get(tokens.get(1)).get()));
        appartmentRepository.addWaterDistribution(new WaterDistribution(tokens.get(2)));
    }
    
}
