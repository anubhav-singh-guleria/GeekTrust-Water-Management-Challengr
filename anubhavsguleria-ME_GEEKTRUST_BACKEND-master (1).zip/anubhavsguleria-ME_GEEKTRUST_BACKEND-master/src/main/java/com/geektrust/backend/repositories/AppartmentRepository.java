package com.geektrust.backend.repositories;

import java.util.ArrayList;
import java.util.List;

import com.geektrust.backend.entities.Appartment;
import com.geektrust.backend.entities.WaterDistribution;

public class AppartmentRepository {
    private List<Appartment> appartmentList;
    private List<WaterDistribution> waterDistributionList;
    public AppartmentRepository(List<Appartment> appartmentList, List<WaterDistribution> waterDistributionList) {
        this.appartmentList = appartmentList;
        this.waterDistributionList = waterDistributionList;
    }

    public AppartmentRepository(){
        this.appartmentList = new ArrayList<Appartment>();
        this.waterDistributionList = new ArrayList<WaterDistribution>();
    }
    public void addAppartment(Appartment appartment){
        appartmentList.add(appartment);
    }
    public Appartment getAppartmentById(Integer id){
        return appartmentList.get(id);
    }

    public void deleteAppartmentById(int id){
        appartmentList.remove(id);
    }

    public void addWaterDistribution(WaterDistribution waterDistribution){
        waterDistributionList.add(waterDistribution);
    }

    public WaterDistribution getWaterDistributionById(int id){
        return waterDistributionList.get(id);
    }

    public void deleteWaterDistributionById(int id){
        waterDistributionList.remove(id);
    }

    public int sizeAppartmentList(){
        return appartmentList.size();
    }

    public int sizeWaterDistribution(){
        return waterDistributionList.size();
    }
}
