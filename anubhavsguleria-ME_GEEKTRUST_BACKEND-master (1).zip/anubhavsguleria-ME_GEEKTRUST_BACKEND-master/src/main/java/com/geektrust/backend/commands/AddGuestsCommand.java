package com.geektrust.backend.commands;

import java.util.List;

import com.geektrust.backend.entities.Appartment;
import com.geektrust.backend.repositories.AppartmentRepository;

public class AddGuestsCommand implements ICommand{
    private AppartmentRepository appartmentRepository;
    
    public AddGuestsCommand(AppartmentRepository appartmentRepository) {
        this.appartmentRepository = appartmentRepository;
    }

    @Override
    public void execute(List<String> tokens) {
        // TODO Auto-generated method stub
        Appartment appartment = appartmentRepository.getAppartmentById(0);
        Integer guests = Integer.valueOf(tokens.get(1));
        appartment.addGuest(guests);
    }

    
    
}
