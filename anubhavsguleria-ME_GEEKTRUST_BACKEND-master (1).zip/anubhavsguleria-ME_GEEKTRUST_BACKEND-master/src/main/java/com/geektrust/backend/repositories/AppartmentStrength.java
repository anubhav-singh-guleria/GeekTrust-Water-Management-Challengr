package com.geektrust.backend.repositories;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import com.geektrust.backend.App;

public class AppartmentStrength {
    private Map<String,Integer> appartmentStrengthMap;
    public AppartmentStrength(){
        this.appartmentStrengthMap = new HashMap<String,Integer>();
    }
    public void setAppartmentStrengthMap(Map<String, Integer> appartmentStrengthMap) {
        this.appartmentStrengthMap = appartmentStrengthMap;
    }

    public Map<String, Integer> getAppartmentStrengthMap() {
        return appartmentStrengthMap;
    }

    public AppartmentStrength(Map<String, Integer> appartmentStrengthMap) {
        this.appartmentStrengthMap = appartmentStrengthMap;
    }

    public void add(String id,Integer strength){
        this.appartmentStrengthMap.put(id, strength);
    }

    public Optional<Integer> get(String id){
        return Optional.ofNullable(this.appartmentStrengthMap.get(id));
    }

    public boolean searchById(String id){
        return appartmentStrengthMap.containsKey(id);
    }

    public void deleteById(String id){
        appartmentStrengthMap.remove(id);
    }
     public int getSize(){
         return appartmentStrengthMap.size();
     }
}
