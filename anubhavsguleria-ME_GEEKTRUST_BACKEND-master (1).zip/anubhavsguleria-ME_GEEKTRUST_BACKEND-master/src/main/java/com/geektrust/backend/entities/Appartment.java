package com.geektrust.backend.entities;

public class Appartment {
    private String type;
    private Integer people;
    private Integer waterAllotedPerPerson;
    private Integer guests=0;
    
    public Appartment(String type, Integer people, Integer waterAllotedPerPerson) {
        this.type = type;
        this.people = people;
        this.waterAllotedPerPerson = waterAllotedPerPerson;
    
    }

    public Appartment(String type,Integer people){
        this.type = type;
        this.people = people;
        this.waterAllotedPerPerson = 10;
    }
    public Appartment() {
        this.waterAllotedPerPerson = 10;
    }

    public Integer waterAlloted(){
        return waterAllotedPerPerson*people*30;
    }


    public void addGuest(Integer guests){
        this.guests += guests;
    }
    public Integer extraWater(){
        return this.guests*waterAllotedPerPerson*30;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((type == null) ? 0 : type.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Appartment other = (Appartment) obj;
        if (type == null) {
            if (other.type != null)
                return false;
        } else if (!type.equals(other.type))
            return false;
        return true;
    }

}
