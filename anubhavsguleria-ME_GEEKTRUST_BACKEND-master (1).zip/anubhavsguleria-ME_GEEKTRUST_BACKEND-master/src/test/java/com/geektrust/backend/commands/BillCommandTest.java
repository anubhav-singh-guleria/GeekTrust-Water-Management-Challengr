package com.geektrust.backend.commands;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import com.geektrust.backend.entities.Appartment;
import com.geektrust.backend.entities.WaterDistribution;
import com.geektrust.backend.repositories.AppartmentRepository;
import com.geektrust.backend.services.CalculateBill;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("BillCommandTest")
public class BillCommandTest {
    private final PrintStream standardOut = System.out;
    private final ByteArrayOutputStream outputStreamCaptor = new ByteArrayOutputStream();


    @BeforeEach
    public void setUp() {
        System.setOut(new PrintStream(outputStreamCaptor));
    }
    @Test
    @DisplayName("Check the Bill Command")
    public void checkBillCommand(){
        CalculateBill calculateBill = new CalculateBill();
        AppartmentRepository appartmentRepository = new AppartmentRepository();
        BillCommand billCommand = new BillCommand(appartmentRepository, calculateBill);
        Appartment appartment = new Appartment("2", 3);
        WaterDistribution waterDistribution = new WaterDistribution("3:7");
        appartmentRepository.addAppartment(appartment);
        appartmentRepository.addWaterDistribution(waterDistribution);
        appartment.addGuest(5);
        List<String> tokens = new ArrayList<String>();
        tokens.add("BILL");
        String epeString = "2400 5215";
        billCommand.execute(tokens);
        Assertions.assertEquals(epeString, outputStreamCaptor.toString().trim());

    }

    @AfterEach
    public void tearDown() {
        System.setOut(standardOut);
    }
}
