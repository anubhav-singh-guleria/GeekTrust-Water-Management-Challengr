package com.geektrust.backend.repositories;

import com.geektrust.backend.entities.Appartment;
import com.geektrust.backend.entities.WaterDistribution;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("AppartmentRepositoryTest")
public class AppartmentRepositoryTest {
    @Test
    @DisplayName("check AddAppartment Method")
    public void chechAddAppartment(){
        AppartmentRepository appartmentRepository = new AppartmentRepository();
        Appartment appartment = new Appartment("2", 5);
        appartmentRepository.addAppartment(appartment);
        Assertions.assertEquals(appartmentRepository.getAppartmentById(0), appartment);
    }

    @Test
    @DisplayName("Check addWaterDistribution")
    public void checkAddWaterDistribution(){
        AppartmentRepository appartmentRepository = new AppartmentRepository();
        WaterDistribution waterDistribution = new WaterDistribution("3:7");
        appartmentRepository.addWaterDistribution(waterDistribution);
        Assertions.assertEquals(appartmentRepository.getWaterDistributionById(0), waterDistribution);
    }
}
