package com.geektrust.backend;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
@DisplayName("AppTest")
class AppTest {
    private final PrintStream standardOut = System.out;
    private final ByteArrayOutputStream outputStreamCaptor = new ByteArrayOutputStream();


    @BeforeEach
    public void setUp() {
        System.setOut(new PrintStream(outputStreamCaptor));
    }

    @Test
    @DisplayName("Integration Test #1")
    void runTest1(){
        List<String> arguments= new ArrayList<>(List.of("sample_input/input1.txt"));
        String expString = "2400 5215";
        App.run(arguments);
        Assertions.assertEquals(expString, outputStreamCaptor.toString().trim());
    }
    
    @Test
    @DisplayName("Integration Test #2")
    void runTest2(){
        List<String> arguments= new ArrayList<>(List.of("sample_input/input2.txt"));
        String expString = "3000 5750";
        App.run(arguments);
        Assertions.assertEquals(expString, outputStreamCaptor.toString().trim());
    }

    @Test
    @DisplayName("Integration Test #3")
    void runTest3(){
        List<String> arguments= new ArrayList<>(List.of("sample_input/input3.txt"));
        String expString = "900 1200";
        App.run(arguments);
        Assertions.assertEquals(expString, outputStreamCaptor.toString().trim());
    }

    @AfterEach
    public void tearDown() {
        System.setOut(standardOut);
    }

}
