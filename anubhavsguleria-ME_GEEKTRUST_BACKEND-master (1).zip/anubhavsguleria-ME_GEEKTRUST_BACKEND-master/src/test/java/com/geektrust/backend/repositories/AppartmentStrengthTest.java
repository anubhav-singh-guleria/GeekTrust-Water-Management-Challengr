package com.geektrust.backend.repositories;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("ppartmentStrengthTest")
public class AppartmentStrengthTest {
    @Test
    @DisplayName("Check get method")
    public void getTest(){
        AppartmentStrength appartmentStrength = new AppartmentStrength();
        appartmentStrength.add("2", 3);
        appartmentStrength.add("3", 5);
        Integer expected = 3;
        Assertions.assertEquals(expected, appartmentStrength.get("2").get());
    }

    @Test
    @DisplayName("check deleteById method")
    public void deleteByIdTest(){
        AppartmentStrength appartmentStrength = new AppartmentStrength();
        appartmentStrength.add("2", 3);
        appartmentStrength.add("3", 5);
        appartmentStrength.deleteById("2");
        Assertions.assertEquals(1,appartmentStrength.getSize());
    }
}
