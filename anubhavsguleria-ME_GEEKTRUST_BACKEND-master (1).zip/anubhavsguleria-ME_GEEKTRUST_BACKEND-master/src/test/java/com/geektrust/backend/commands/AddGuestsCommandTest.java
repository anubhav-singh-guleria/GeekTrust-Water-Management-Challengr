package com.geektrust.backend.commands;

import java.util.ArrayList;
import java.util.List;

import com.geektrust.backend.entities.Appartment;
import com.geektrust.backend.repositories.AppartmentRepository;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("AddGuestsCommandTest")
public class AddGuestsCommandTest {
    @Test
    @DisplayName("Check execute function")
    public void testAddGuestCommand(){
        List<String> tokens = new ArrayList<String>();
        tokens.add("ADD_GUESTS");
        tokens.add("5");
        AppartmentRepository appartmentRepository = new AppartmentRepository();
        AddGuestsCommand addGuestsCommand = new AddGuestsCommand(appartmentRepository);
        appartmentRepository.addAppartment(new Appartment("2",3));
        addGuestsCommand.execute(tokens);
        Assertions.assertEquals(5, appartmentRepository.getAppartmentById(0).extraWater()/(30*10));
    }
}
