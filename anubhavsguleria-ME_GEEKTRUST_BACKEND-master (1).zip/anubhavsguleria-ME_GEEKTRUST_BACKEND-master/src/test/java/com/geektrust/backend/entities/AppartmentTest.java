package com.geektrust.backend.entities;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("AppartmentTest")
public class AppartmentTest {
    @Test
    @DisplayName("Check if addGuest Method adds guests in the appartment")
    public void checkIfAddGuestWorks(){
        String type = "2";
        Integer people  = 3;
        Integer waterAllotedPerPerson = 10;
        Appartment appartment = new Appartment(type, people, waterAllotedPerPerson);
        Integer expectedOutput = 10;
        appartment.addGuest(10);
        Assertions.assertEquals(expectedOutput, appartment.extraWater()/(30*10));
    }

    @Test
    @DisplayName("Check if extraWater Method gives the total amount of water")
    public void checkExtraWater(){
        String type = "2";
        Integer people  = 3;
        Integer waterAllotedPerPerson = 10;
        Appartment appartment = new Appartment(type, people, waterAllotedPerPerson);
        appartment.addGuest(5);
        Integer expected = 1500;
        Assertions.assertEquals(expected, appartment.extraWater());
    }

    @Test
    @DisplayName("Check WaterAllotedMethod")
    public void waterAllotedTest(){
        String type = "2";
        Integer people  = 3;
        Integer waterAllotedPerPerson = 10;
        Appartment appartment = new Appartment(type, people, waterAllotedPerPerson);
        Assertions.assertEquals(900, appartment.waterAlloted());
    }

    @Test
    @DisplayName("Check equals method")
    public void checkEquals(){
        Appartment appartment1 = new Appartment("2", 3);
        Appartment appartment2 = new Appartment("2", 3);
        Assertions.assertEquals(true, appartment1.equals(appartment2));
    }

}
