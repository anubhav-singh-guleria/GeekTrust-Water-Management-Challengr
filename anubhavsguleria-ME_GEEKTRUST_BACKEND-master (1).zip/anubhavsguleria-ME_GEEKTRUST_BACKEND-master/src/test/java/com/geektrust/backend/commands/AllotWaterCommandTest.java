package com.geektrust.backend.commands;

import java.util.ArrayList;
import java.util.List;

import com.geektrust.backend.repositories.AppartmentRepository;
import com.geektrust.backend.repositories.AppartmentStrength;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;


@DisplayName("AllotWaterCommandTest")
public class AllotWaterCommandTest {
    @Test
    @DisplayName("Check execute method 1")
    public void checkExecuteMethod1(){
        AppartmentRepository appartmentRepository = new AppartmentRepository();
        AppartmentStrength appartmentStrength = new AppartmentStrength();
        AllotWaterCommand allotWaterCommand = new AllotWaterCommand(appartmentRepository, appartmentStrength);
        List<String> tokens = new ArrayList<String>();
        tokens.add("ALLOT_WATER");
        tokens.add("2");
        tokens.add("3:7");
        allotWaterCommand.execute(tokens);
        Assertions.assertEquals(1, appartmentRepository.sizeAppartmentList());

    }

    @Test
    @DisplayName("Check execute method 2")
    public void checkExecuteMethod2(){
        AppartmentRepository appartmentRepository = new AppartmentRepository();
        AppartmentStrength appartmentStrength = new AppartmentStrength();
        AllotWaterCommand allotWaterCommand = new AllotWaterCommand(appartmentRepository, appartmentStrength);
        List<String> tokens = new ArrayList<String>();
        tokens.add("ALLOT_WATER");
        tokens.add("2");
        tokens.add("3:7");
        allotWaterCommand.execute(tokens);
        Assertions.assertEquals(1, appartmentRepository.sizeWaterDistribution());

    }
}
