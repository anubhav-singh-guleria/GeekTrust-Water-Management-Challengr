package com.geektrust.backend.entities;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("WaterDistributionTest")
public class WaterDistributionTest {
    @Test
    @DisplayName("Check getIntRatio method")
    public void getIntRatioTest(){
        WaterDistribution waterDistribution = new WaterDistribution(1.0, 1.5, "3:7");
        Integer[] expected = {3,7};
        for(int i = 0;i<2;i++){
            Integer expInteger = expected[i];
            Assertions.assertEquals(expInteger,waterDistribution.getIntRatio()[i]);
        }
    }
    @Test
    @DisplayName("Check returnRates Method")
    public void returnRatesTest(){
        WaterDistribution waterDistribution = new WaterDistribution(1.0, 1.5, "3:7");
        Double[] expected = {1.0,1.5};
        for(int i = 0;i<2;i++){
            Double expInteger = expected[i];
            Assertions.assertEquals(expInteger,waterDistribution.returnRates()[i]);
        }
    }

    @Test
    @DisplayName("check calculateWaterTankerRate method")
    public void calculateWaterTankerRateTest1(){
        WaterDistribution waterDistribution = new WaterDistribution("3:7");
        Assertions.assertEquals(2500,waterDistribution.calculateWaterTankerRate(1000));
    }

    @Test
    @DisplayName("check calculateWaterTankerRate method")
    public void calculateWaterTankerRateTest2(){
        WaterDistribution waterDistribution = new WaterDistribution("3:7");
        Assertions.assertEquals(59500,waterDistribution.calculateWaterTankerRate(9000));
    }

    @Test
    @DisplayName("check calculateWaterTankerRate method")
    public void calculateWaterTankerRateTest3(){
        WaterDistribution waterDistribution = new WaterDistribution("3:7");
        Assertions.assertEquals(24060,waterDistribution.calculateWaterTankerRate(4570));
    }

}
